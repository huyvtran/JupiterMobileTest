export class StorageRoot {
  constructor() {
     // assign local variables to class members
  }
}